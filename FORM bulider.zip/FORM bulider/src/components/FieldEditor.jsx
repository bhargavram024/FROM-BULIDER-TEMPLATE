
import React from 'react';

const FIELD_TYPES = ['Label_H1', 'Label_H2', 'Label_H3', 'Text', 'Number', 'Boolean', 'Enum'];

export default function FieldEditor({ field, onChange, onDelete }) {
  const handleChange = (key, value) => {
    onChange({ ...field, [key]: value });
  };

  return (
    <div className="border p-2 rounded bg-white mb-2">
      <div className="flex justify-between items-center mb-1">
        {/* Field Label */}
        <input
          type="text"
          value={field.label}
          onChange={(e) => handleChange('label', e.target.value)}
          className="border px-2 py-1 w-1/2"
        />

        {/* Field Type */}
        <select
          value={field.type}
          onChange={(e) => handleChange('type', e.target.value)}
          className="border px-2 py-1"
        >
          {FIELD_TYPES.map(type => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>

        {/* Delete Button */}
        <button
          onClick={onDelete}
          className="text-red-500 text-sm"
        >
          Delete
        </button>
      </div>

      {/* Enum Options Field */}
      {field.type === 'Enum' && (
        <input
          type="text"
          placeholder="Comma-separated options"
          value={field.options?.join(',') || ''}
          onChange={(e) => handleChange('options', e.target.value.split(',').map(opt => opt.trim()))}
          className="border px-2 py-1 w-full"
        />
      )}
    </div>
  );
}
