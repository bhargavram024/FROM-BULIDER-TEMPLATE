import React, { useState } from 'react';

export default function FormRenderer({ templates }) {
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [formData, setFormData] = useState({});
  const [submittedData, setSubmittedData] = useState(null);

  const selectedTemplate = templates.find(t => t.id === selectedTemplateId);

  const handleChange = (fieldId, value) => {
    setFormData({ ...formData, [fieldId]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const key = `formData-${selectedTemplateId}`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const updated = [...existing, formData];

    localStorage.setItem(key, JSON.stringify(updated));
    setSubmittedData(formData);
    setFormData({});
  };

  return (
    <div className="border p-4 bg-white rounded">
      <div className="mb-4">
        <label className="block mb-1 font-medium">Select Template</label>
        <select
          value={selectedTemplateId}
          onChange={(e) => {
            setSelectedTemplateId(e.target.value);
            setFormData({});
            setSubmittedData(null);
          }}
          className="border px-3 py-2 w-full"
        >
          <option value="">-- Select a template --</option>
          {templates.map(t => (
            <option key={t.id} value={t.id}>{t.name}</option>
          ))}
        </select>
      </div>

      {selectedTemplate && (
        <>
          <form onSubmit={handleSubmit} className="space-y-4">
            {selectedTemplate.sections.map(section => (
              <div key={section.id}>
                <h3 className="text-lg font-semibold mb-2">{section.title}</h3>
                {section.fields.map(field => (
                  <div key={field.id} className="mb-3">
                    <label className="block font-medium mb-1">
                      {field.label}
                    </label>

                    {field.type.startsWith('Label_') ? (
                      React.createElement(
                        field.type.replace('Label_', 'h'),
                        { className: 'font-bold mb-2' },
                        field.label
                      )
                    ) : field.type === 'Text' ? (
                        <input
                          type="text"
                          className="border px-3 py-2 w-full"
                          value={formData[field.id] || ''}
                          onChange={(e) => handleChange(field.id, e.target.value)}
                          maxLength={field.maxLength || 100}
                          required
                        />
                      ) : field.type === 'Paragraph' ? (
                        <textarea
                          className="border px-3 py-2 w-full"
                          value={formData[field.id] || ''}
                          onChange={(e) => handleChange(field.id, e.target.value)}
                          rows={4}
                        />

                      
                    ) : field.type === 'Number' ? (
                      <input
                        type="number"
                        className="border px-3 py-2 w-full"
                        value={formData[field.id] || ''}
                        onChange={(e) => handleChange(field.id, e.target.value)}
                        required
                      />
                    ) : field.type === 'Boolean' ? (
                      <input
                        type="checkbox"
                        checked={formData[field.id] || false}
                        onChange={(e) => handleChange(field.id, e.target.checked)}
                      />
                    ) : field.type === 'Enum' ? (
                      <select
                        className="border px-3 py-2 w-full"
                        value={formData[field.id] || ''}
                        onChange={(e) => handleChange(field.id, e.target.value)}
                        required
                      >
                        <option value="">-- Select --</option>
                        {field.options.map((opt, idx) => (
                          <option key={idx} value={opt}>{opt}</option>
                        ))}
                      </select>
                    ) : field.type === 'Upload' || field.type === 'Image' ? (
                      <input
                        type="file"
                        accept={field.accept || '*'}
                        className="border px-3 py-2 w-full"
                        onChange={(e) => handleChange(field.id, e.target.files[0])}
                      />
                    ) : null}
                  </div>
                ))}
              </div>
            ))}

            <button
              type="submit"
              className="bg-green-600 text-white px-4 py-2 rounded"
            >
              Submit
            </button>
          </form>

          {submittedData && (
            <div className="mt-6 p-4 border bg-green-50 rounded">
              <h2 className="text-xl font-bold mb-2">✅ Form Submitted</h2>
              <pre className="bg-white p-3 rounded overflow-x-auto text-sm">
                {JSON.stringify(submittedData, null, 2)}
              </pre>
            </div>
          )}
        </>
      )}
    </div>
  );
}
