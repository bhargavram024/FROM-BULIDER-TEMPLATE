// components/FieldToolbox.jsx
import React from 'react';
import { v4 as uuidv4 } from 'uuid';

const groupedFields = [
  {
    group: '📄 Text Elements',
    items: [
      { type: 'Text', label: '📝 Short Answer' },
      { type: 'Text', label: '📄 Paragraph' }
    ]
  },
  {
    group: '✅ Multiple Choice',
    items: [
      { type: 'Enum', label: '⬇️ Dropdown' },
      { type: 'Boolean', label: '✅ Yes / No' }
    ]
  },
  {
    group: '🖼️ Media Elements',
    items: [
      { type: 'Upload', label: '📎 Upload (PDF/JPG)', accept: '.pdf,.jpg,.jpeg' },
      { type: 'Image', label: '🖼️ Image Upload (JPG/PNG)', accept: '.jpg,.jpeg,.png' }
    ]
  }
];

export default function FieldToolbox({ onInsertField }) {
  const handleClick = (type, accept) => {
    const newField = {
      id: uuidv4(),
      label: `${type} Field`,
      type,
      accept: accept || undefined,
      options: type === 'Enum' ? ['Option 1', 'Option 2'] : undefined
    };
    onInsertField(newField);
  };

  return (
    <div className="h-screen flex flex-col overflow-y-auto">
      <h2 className="text-xl font-bold mb-4 text-gray-800">🧰 Field Toolbox</h2>
      <div className="space-y-6">
        {groupedFields.map((group) => (
          <div key={group.group}>
            <h3 className="text-sm font-semibold text-gray-600 mb-2">{group.group}</h3>
            <div className="grid grid-cols-2 gap-3">
              {group.items.map((field) => (
                <button
                  key={field.type}
                  onClick={() => handleClick(field.type, field.accept)}
                  className="bg-white border border-gray-300 rounded-lg shadow-sm hover:bg-blue-100 hover:border-blue-400 transition-all duration-200 text-sm font-medium text-gray-700 p-3 text-center"
                >
                  {field.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
