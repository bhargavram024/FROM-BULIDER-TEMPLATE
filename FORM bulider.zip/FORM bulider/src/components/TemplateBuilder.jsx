
import React, { useEffect } from 'react';
import SectionEditor from './SectionEditor';
import { v4 as uuidv4 } from 'uuid';

export default function TemplateBuilder({ template, onUpdate }) {
  //  Auto-save to localStorage whenever template updates
  useEffect(() => {
    if (template?.id) {
      const saved = JSON.parse(localStorage.getItem('templates')) || [];
      const existingIndex = saved.findIndex(t => t.id === template.id);

      if (existingIndex >= 0) {
        saved[existingIndex] = template;
      } else {
        saved.push(template);
      }

      localStorage.setItem('templates', JSON.stringify(saved));
    }
  }, [template]);

  const addSection = () => {
    const newSection = {
      id: uuidv4(),
      title: 'New Section',
      fields: []
    };
    const updated = {
      ...template,
      sections: [...template.sections, newSection]
    };
    onUpdate(updated);
  };

  const updateSection = (index, updatedSection) => {
    const updatedSections = [...template.sections];
    updatedSections[index] = updatedSection;
    onUpdate({ ...template, sections: updatedSections });
  };

  const deleteSection = (index) => {
    const updatedSections = [...template.sections];
    updatedSections.splice(index, 1);
    onUpdate({ ...template, sections: updatedSections });
  };

  return (
    <div className="bg-white p-4 rounded shadow">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">🧱 Template: {template.name}</h2>
        <button
          onClick={addSection}
          className="bg-blue-500 text-white px-3 py-1 rounded"
        >+ Add Section</button>
      </div>

      {template.sections.length === 0 && (
        <p className="text-gray-500">No sections added yet. Click the button above to add one.</p>
      )}

      <div className="space-y-4">
        {template.sections.map((section, index) => (
          <SectionEditor
            key={section.id}
            section={section}
            onUpdate={(updated) => updateSection(index, updated)}
            onDelete={() => deleteSection(index)}
          />
        ))}
      </div>
    </div>
  );
}
