
import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { v4 as uuidv4 } from 'uuid';
import { reorder } from '../utils/dragUtils';

const FIELD_TYPES = ['Label_H1', 'Label_H2', 'Label_H3', 'Text', 'Number', 'Boolean', 'Enum'];

export default function SectionEditor({ section, onUpdate, onDelete }) {
  const [localSection, setLocalSection] = useState(section);

  const handleFieldAdd = () => {
    const newField = {
      id: uuidv4(),
      label: 'New Field',
      type: 'Text',
      options: [],
    };
    const updated = { ...localSection, fields: [...localSection.fields, newField] };
    setLocalSection(updated);
    onUpdate(updated);
  };

  const handleFieldDelete = (id) => {
    const updatedFields = localSection.fields.filter(f => f.id !== id);
    const updated = { ...localSection, fields: updatedFields };
    setLocalSection(updated);
    onUpdate(updated);
  };

  const handleFieldChange = (id, key, value) => {
    const updatedFields = localSection.fields.map(f =>
      f.id === id ? { ...f, [key]: value } : f
    );
    const updated = { ...localSection, fields: updatedFields };
    setLocalSection(updated);
    onUpdate(updated);
  };

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const reordered = reorder(localSection.fields, result.source.index, result.destination.index);
    const updated = { ...localSection, fields: reordered };
    setLocalSection(updated);
    onUpdate(updated);
  };

  return (
    <div className="border p-4 rounded bg-gray-50">
      <div className="flex justify-between items-center mb-2">
        <input
          type="text"
          className="text-lg font-bold border-b focus:outline-none bg-transparent"
          value={localSection.title}
          onChange={(e) => {
            const updated = { ...localSection, title: e.target.value };
            setLocalSection(updated);
            onUpdate(updated);
          }}
        />
        <button onClick={onDelete} className="text-red-500 text-sm">Delete Section</button>
      </div>

      <button
        onClick={handleFieldAdd}
        className="bg-blue-500 text-white px-2 py-1 text-sm rounded mb-2"
      >
        + Add Field
      </button>

      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId={`section-${section.id}`}>
          {(provided) => (
            <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-2">
              {localSection.fields.map((field, index) => (
                <Draggable key={field.id} draggableId={field.id} index={index}>
                  {(provided) => (
                    <div
                      className="border p-2 rounded bg-white"
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                    >
                      <div className="flex justify-between items-center mb-1">
                        <input
                          type="text"
                          value={field.label}
                          onChange={(e) => handleFieldChange(field.id, 'label', e.target.value)}
                          className="border px-2 py-1 w-1/2"
                        />
                        <select
                          value={field.type}
                          onChange={(e) => handleFieldChange(field.id, 'type', e.target.value)}
                          className="border px-2 py-1"
                        >
                          {FIELD_TYPES.map(t => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                        <button
                          onClick={() => handleFieldDelete(field.id)}
                          className="text-red-500 text-sm"
                        >
                          Delete
                        </button>
                      </div>
                      {field.type === 'Enum' && (
                        <input
                          type="text"
                          placeholder="Comma-separated options"
                          value={field.options?.join(',') || ''}
                          onChange={(e) =>
                            handleFieldChange(field.id, 'options', e.target.value.split(',').map(opt => opt.trim()))
                          }
                          className="border px-2 py-1 w-full"
                        />
                      )}
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
}