// utils/dragUtils.js

/**
 * Reorders a list based on drag result.
 *@param {Array} list - The array of items to reorder.
 * @param {number} startIndex - The index from which the item was dragged.
 * @param {number} endIndex - The index to which the item was dropped.
 * @returns {Array} - New reordered array.
 */
export function reorder(list, startIndex, endIndex) {
  const result = Array.from(list); // clone the array
  const [removed] = result.splice(startIndex, 1); // remove the dragged item
  result.splice(endIndex, 0, removed); // insert it in new position
  return result;
}
