import React, { useState, useEffect } from 'react';
import TemplateBuilder from "./components/TemplateBuilder";
import FormRenderer from './components/FormRenderer';
import FieldToolbox from './components/FieldToolbox';
import { v4 as uuidv4 } from 'uuid';

export default function App() {
  const [templates, setTemplates] = useState([]);
  const [activeTemplateId, setActiveTemplateId] = useState(null);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('templates')) || [];
    setTemplates(saved);
  }, []);

  useEffect(() => {
    localStorage.setItem('templates', JSON.stringify(templates));
  }, [templates]);

  const createTemplate = () => {
    if (templates.length >= 5) {
      alert("Maximum of 5 templates allowed.");
      return;
    }

    const newTemplate = {
      id: Date.now().toString(),
      name: `Template ${templates.length + 1}`,
      sections: []
    };

    setTemplates([...templates, newTemplate]);
    setActiveTemplateId(newTemplate.id);
  };

  const updateTemplate = (updatedTemplate) => {
    const updatedTemplates = templates.map(t =>
      t.id === updatedTemplate.id ? updatedTemplate : t
    );
    setTemplates(updatedTemplates);
  };

  const handleInsertField = (field) => {
    if (!activeTemplateId) {
      alert("Please select a template first.");
      return;
    }

    const updatedTemplates = templates.map(t => {
      if (t.id === activeTemplateId) {
        const sections = [...t.sections];
        if (sections.length === 0) {
          sections.push({ id: uuidv4(), title: "New Section", fields: [field] });
        } else {
          sections[0].fields.push(field);
        }
        return { ...t, sections };
      }
      return t;
    });

    setTemplates(updatedTemplates);
  };

  const selectedTemplate = templates.find(t => t.id === activeTemplateId);

  return (
    <div className="flex h-screen w-screen">
      {/* 🔵 Left: Builder + Renderer */}
      <div className="flex-1 bg-gray-50 p-6 overflow-y-auto">
        <header className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">📋 Form Template Builder</h1>
        </header>

        <div className="flex items-center gap-3 mb-4">
          <label className="font-medium">Select Template:</label>
          <select
            className="border px-3 py-2 rounded"
            value={activeTemplateId || ''}
            onChange={(e) => setActiveTemplateId(e.target.value)}
          >
            <option value="">-- Choose --</option>
            {templates.map(t => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </select>
        </div>

        {selectedTemplate ? (
          <TemplateBuilder
            template={selectedTemplate}
            onUpdate={updateTemplate}
          />
        ) : (
          <p className="text-gray-600 italic">No template selected.</p>
        )}

        <div className="pt-8 border-t mt-6">
          <h2 className="text-xl font-semibold mb-3">📝 Fill Form from Template</h2>
          <FormRenderer templates={templates} />
        </div>
      </div>

      {/* 🟡 Right: Toolbox Panel */}
      <div className="w-80 h-screen bg-white border-l shadow-inner flex flex-col">
        {/* Header & Create Button */}
        <div className="p-4 border-b">
          <h2 className="text-lg font-semibold mb-2">📋 Templates</h2>
          <button
            onClick={createTemplate}
            className="w-full bg-blue-600 text-white px-3 py-2 rounded hover:bg-blue-700 transition"
          >
            + Create New Template
          </button>
        </div>

        {/* Field Toolbox Scrollable Area */}
        <div className="flex-1 overflow-y-auto p-4">
          <FieldToolbox onInsertField={handleInsertField} />
        </div>
      </div>
    </div>
  );
}
